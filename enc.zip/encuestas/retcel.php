 !DOCTYPE html>
<html lang="es">
    <head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
        
        <title>Halza Encuesta </title>
		</head>
		<body>
		<script>
if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
   document.write("style='width:30px;height:30px;'");
}
else { 	document.write("aa"); }
</script>
</body>
</html>