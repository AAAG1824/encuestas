<?php  
$strPermAprobar 		=  substr($strUsrRol,5,1);
$strPermAdministrar 	=  substr($strUsrRol,10,1);
$strPermUsuarios	 	=  substr($strUsrRol,20,1);
$strPermPermisos	 	=  substr($strUsrRol,25,1);
$strPermProblemas	 	=  substr($strUsrRol,30,1);
$strPermCategorias		=  substr($strUsrRol,35,1);
$strPermSubcategoria	=  substr($strUsrRol,40,1);
$strPermCatProblemas	=  substr($strUsrRol,45,1);
$strPermCorreos			=  substr($strUsrRol,50,1);
$strPermReportes		=  substr($strUsrRol,80,1);
$strPermAsignar			=  substr($strUsrRol,60,1);
/*
1111000000
0000000000
0000000000
0000000000
0000000000
0000000000
0000000000
0000000000
0000000000
0000000000
*/


?>

