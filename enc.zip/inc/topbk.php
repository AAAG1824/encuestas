﻿ <!-- Sidebar Toggle (Topbar) -->
          <a class="sidebar-brand d-flex align-items-center justify-content-center bg-gradient-primary " href="login.php">
        <div class="sidebar-brand-text mx-3"><img src="img/logobco.png"></div>
      </a> <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
      
          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">
    <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <script>      
var meses = new Array ("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
var diasSemana = new Array("Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado");
var f=new Date();
document.write("a " + diasSemana[f.getDay()] + ", " + f.getDate() + " de " + meses[f.getMonth()] + " de " + f.getFullYear());
</script> 
               
            </li>
  </ul> 